//Khadija Irfan
//20I-0803
//Project
#include <iostream>
#include <ctime>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <fstream>
using namespace std;
class Room; //defining classes so order of defination does not give errors
class Hotel;
class Customer;
class Standard;
class Moderate;
class Superior;
class JuniorSuite;
class Suite;

Room **allrooms; //Global Variable
class Hotel
{
protected:
    static int num; //counts number of customers
    Customer *cust;
public:
    void Management(); //Driver Function
    static int getnum(); //Number getter 
    void MenuDisplay(); 
    void view();
    Hotel();
    ~Hotel();
};
class DateTime
{
private:
    int hours;
    int min;
    int year;
    int month;
    int day;
    string Date;
    string Time;

public:
    DateTime();
    string getDate();
    string getTime();
    void setDate(int yr, int mon, int day);
    void setTime(int hrs, int min);
    ~DateTime();
};
class Customer
{
private:
    string fullname;
    int age;
    string gender;
    int Id;

public:
    Customer();
    string getname();
    int getage();
    string getgender();
    int getId();
    void setdata();
    ~Customer();
};
class Room
{
protected:
    Room *roomType; //there was no need of this but didnt have time to delete
    Customer *c; //aggregation
    int roomNum;
    DateTime checkin; //composition
    DateTime checkout; //composition
    double balance;
    int daysReserved;
    int floorNum;
    bool reservecheck;
    double price;

public:
    Room();
    int getroomNum();
    int getfloorNum();
    Room* getroomType();
    int getdaysReserved();
    double getbalance();
    double getprice();
    void setcustomer(Customer &c);
    Customer* getcustomer();
    DateTime getcheckout();
    DateTime getcheckin();
    void detailreport();
    Room &operator=(Room &);
    bool getreservecheck();
    void setreservecheck(bool);
    void roomsAvailable();
    void ReservedRooms();
    void setData();
    bool reserveRoom();
    void custcheckin(Customer);
    void custcheckout();
    ~Room();
};
ostream &operator<<(ostream &output, Room r1);
ostream &operator<<(ostream &output, Customer c1);
class Standard : public Room
{
private:
public:
    Standard();
    ~Standard();
};
class Moderate : public Room
{
private:
public:
    Moderate();
    ~Moderate();
};
class Superior : public Room
{
private:
public:
    Superior();
    ~Superior();
};
class JuniorSuite : public Room
{
private:
public:
    JuniorSuite();
    ~JuniorSuite();
};
class Suite : public Room
{
private:
public:
    Suite();
    ~Suite();
};