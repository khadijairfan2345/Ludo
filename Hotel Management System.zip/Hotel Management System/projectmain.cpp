#include "project.cpp"
int main()
{
    char c;
    Hotel c1;
    do
    {
        c1.Management();
        cout << "Do you wish to continue? : ";
        cin >> c;
    } while (c == 'y' || c == 'Y');
}