//Khadija Irfan
//20I-0803
#include "project.h"
void Hotel ::Management()
{
    int i;
    int j;
    int id;
    int choice;
    MenuDisplay();
    view();
    fstream my_file;
    Room temp;
    cin >> choice;
    if (0 < choice <= 5)
    {
        switch (choice)
        {
        case 1:
            cust[num].setdata();
            temp.roomsAvailable();
            temp.reserveRoom();
            temp.setcustomer(cust[num]);
            i = temp.getfloorNum();
            j = temp.getroomNum();
            allrooms[i][j] = temp;
            my_file.open("my_file.dat", ios::out | ios::binary);
            if (!my_file)
            {
                cout << "File not created!";
            }
            my_file.write(reinterpret_cast<char *>(&cust[num]), sizeof(cust[num]));
            my_file.close();
            num++;
            break;
        case 2:
            temp.custcheckin(cust[num]);
            num++;
            break;
        case 3:
            temp.ReservedRooms();
            break;
        case 4:
            cout << "To view your detailed report, enter your ID : ";
            cin >> id;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 50; j++)
                {
                    if (allrooms[i][j].getreservecheck() == 1)
                    {
                        Customer *c1;
                        c1 = allrooms[i][j].getcustomer();
                        cout<<id;
                        cout<<c1->getId();
                        if (id == c1->getId())
                        {
                            allrooms[i][j].detailreport();
                        }
                    }
                }
            }

            break;
        case 5:
            exit(0);
            break;
        }
    }
    else
    {
        cout << "You entered an Invalid Option" << endl;
    }
}
void Hotel ::MenuDisplay()
{
    char esc_char = 27;
    cout << esc_char << "[1m"
         << "\t Welcome to FourSeasons Hotel" << esc_char << "[0m" << endl;
    cout << "1- Press 1 to Reserve a room" << endl;
    cout << "2- Press 2 to Checkin a customer/visitor" << endl;
    cout << "3- Press 3 to View Reserved Rooms" << endl;
    cout << "4- Press 4 to see detailed Report" << endl;
    cout << "5- Press 5 to exit" << endl;
}
void Hotel ::view()
{
    cout << "             OOP Hotel\n";
    cout << "______________________________________________________\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  |  S  |    |  M  |    | Su  |   | JS  |   |Suite|  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  |  S  |    |  M  |    | Su  |   | JS  |   |Suite|  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  |  s  |    |  M  |    | Su  |   | JS  |   |Suite|  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  |  s  |    |  M  |    | Su  |   | JS  |   |Suite|  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "|  |  s  |    |  M  |    | Su  |   | JS  |   |Suite|  |\n";
    cout << "|  -------    -------    -------   -------   -------  |\n";
    cout << "------------------------------------------------------\n";
}
Hotel ::Hotel()
{
    allrooms = new Room *[5];
    for (int i = 0; i < 5; i++)
    {
        allrooms[i] = new Room[50];
    }
    cust = new Customer[250];
    int count = 0;
    for (int i = 0; i < 5; i++)
    {

        allrooms[i] = new Standard[10];
        allrooms[i] = new Moderate[10];
        allrooms[i] = new Superior[10];
        allrooms[i] = new JuniorSuite[10];
        allrooms[i] = new Suite[10];
    }
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 50; j++)
        {
            allrooms[i][j].setreservecheck(0);
        }
    }
}
Hotel ::~Hotel()
{
}
int Hotel ::num = 0;
int Hotel :: getnum()
{
    return num;
}
DateTime ::DateTime()
{
}
string DateTime :: getDate()
{
    return Date;
}
string DateTime :: getTime()
{
    return Time;
}
void DateTime ::setDate(int yr, int mon, int day)
{
    year = yr;
    month = mon;
    this->day = day;
    string syear, smonth, sday;
    syear = to_string(yr);
    sday = to_string(day);
    switch (mon)
    {
    case 1:
        Date = sday + " January, " + syear;
        break;
    case 2:
        Date = sday + " February, " + syear;
        break;
    case 3:
        Date = sday + " March, " + syear;
        break;
    case 4:
        Date = sday + " April, " + syear;
        break;
    case 5:
        Date = sday + " May, " + syear;
        break;
    case 6:
        Date = sday + " June, " + syear;
        break;
    case 7:
        Date = sday + " July, " + syear;
        break;
    case 8:
        Date = sday + " August, " + syear;
        break;
    case 9:
        Date = sday + " September, " + syear;
        break;
    case 10:
        Date = sday + " October, " + syear;
        break;
    case 11:
        Date = sday + " November, " + syear;
        break;
    case 12:
        Date = sday + " Decemeber, " + syear;
        break;
    }
}
void DateTime ::setTime(int hrs, int min)
{
    string shrs, smin;
    shrs = to_string(hrs);
    smin = to_string(min);
    Time = shrs + " : " + smin;
}
DateTime ::~DateTime()
{
}
Customer ::Customer()
{
}
void Customer ::setdata()
{
    //fstream ifile;
    //ifile.open("data.dat", ios::binary);
    char esc_char = 27;
    cout << esc_char << "[1m"
         << " Thank you for choosing our Hotel System for your stay, I hope your time with us is delightful" << esc_char << "[0m" << endl;
    cout << "To proceed forward, we will require some data" << endl;
    cout << "Enter your Full Name: ";
    cin >> fullname;
    //ifile.write(reinterpret_cast<char *>(&fullname), sizeof(string));
    //ifile.close();
    cout << "Enter your Age : ";
    cin >> age;
    int choice;
    cout << "Are you \n1-->Female\n2-->Male\n3-->Other" << endl;
    cin >> choice;
    switch (choice)
    {
    case 1:
        gender = "Female";
        break;
    case 2:
        gender = "Male";
        break;
    case 3:
        gender = "Other";
        break;
    }
    Id = Hotel ::getnum();
    cout << esc_char << "[1m"
         << "Your ID Card Number is : " << Id << esc_char << "[0m" << endl
         << endl;
}
string Customer ::getname()
{
    return fullname;
}
int Customer ::getage()
{
    return age;
}
string Customer ::getgender()
{
    return gender;
}
int Customer ::getId()
{
    return Id;
}
Customer ::~Customer()
{
}
Room ::Room()
{
}
void Room ::setcustomer(Customer &c)
{
    this->c = &c;
}
int Room ::getfloorNum()
{
    return floorNum;
}
int Room ::getroomNum()
{
    return roomNum;
}
void Room ::setreservecheck(bool i)
{
    reservecheck = i;
}
Room *Room ::getroomType()
{
    return roomType;
}
void Room ::detailreport()
{
    cout << *this << endl;
}
void Room ::custcheckin(Customer cust)
{
    fstream my_file;
    Room temp;
    int choice, i, j;
    cout << "Did you reserve a room previously (enter 1) or do you wish to reserve a room and checkin right now (enter 2) ?" << endl;
    cin >> choice;
    if (choice == 1)
    {
        my_file.open("my_file.dat", ios::in | ios::binary);
        my_file.read(reinterpret_cast<char *>(&cust), sizeof(cust));
        my_file.close();
        cout << cust << endl;
        temp.reserveRoom();
        i = temp.getfloorNum();
        j = temp.getroomNum();
        allrooms[i][j] = temp;
    }
    else if (choice == 2)
    {
        cust.setdata();
        temp.roomsAvailable();
        temp.reserveRoom();
        temp.setcustomer(cust);
        i = temp.getfloorNum();
        j = temp.getroomNum();
        allrooms[i][j] = temp;
    }
}
void Room ::custcheckout()
{
}
int Room ::getdaysReserved()
{
    return daysReserved;
}
double Room ::getbalance()
{
    return balance;
}
double Room ::getprice()
{
    return price;
}
Customer *Room ::getcustomer()
{
    return c;
}
DateTime Room ::getcheckout()
{
    return checkout;
}
DateTime Room ::getcheckin()
{
    return checkin;
}
bool Room ::getreservecheck()
{
    return reservecheck;
}
void Room ::roomsAvailable()
{
    int tcount = 0;
    int count = 0;
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (allrooms[i][j].reservecheck == 0)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Standard rooms are available on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 10; j < 20; j++)
        {
            if (allrooms[i][j].reservecheck == 0)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Moderate rooms are available on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 20; j < 30; j++)
        {
            if (allrooms[i][j].reservecheck == 0)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Superior rooms are available on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 30; j < 40; j++)
        {
            if (allrooms[i][j].reservecheck == 0)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Juior Suite rooms are available on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 40; j < 50; j++)
        {
            if (allrooms[i][j].reservecheck == 0)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Suit rooms are available on the " << i + 1 << " floor." << endl
             << endl;
        count = 0;
    }
    cout << endl
         << endl;
    char esc_char = 27;
    cout << esc_char << "[1m"
         << " A total of " << tcount << " rooms are available at the current time" << esc_char << "[0m" << endl;
}
void Room ::ReservedRooms()
{
    int tcount = 0;
    int count = 0;
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (allrooms[i][j].reservecheck == 1)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Standard rooms are reserved on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 10; j < 20; j++)
        {
            if (allrooms[i][j].reservecheck == 1)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Moderate rooms are reserved on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 20; j < 30; j++)
        {
            if (allrooms[i][j].reservecheck == 1)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Superior rooms are reserved on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 30; j < 40; j++)
        {
            if (allrooms[i][j].reservecheck == 1)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Juior Suite rooms are reserved on the " << i + 1 << " floor." << endl;
        count = 0;
        for (int j = 40; j < 50; j++)
        {
            if (allrooms[i][j].reservecheck == 1)
            {
                count++;
                tcount++;
            }
        }
        cout << "A total of " << count << " Suit rooms are reserved on the " << i + 1 << " floor." << endl
             << endl;
        count = 0;
    }
    cout << endl
         << endl;
    char esc_char = 27;
    cout << esc_char << "[1m"
         << " A total of " << tcount << " rooms are reserved at the current time" << esc_char << "[0m" << endl;
}
void Room ::setData()
{
}
Room &Room ::operator=(Room &r1)
{
    roomType = r1.roomType;
    c = r1.c;
    roomNum = r1.roomNum;
    checkin = r1.checkin;
    checkout = r1.checkout;
    balance = r1.balance;
    daysReserved = r1.daysReserved;
    floorNum = r1.floorNum;
    reservecheck = r1.reservecheck;
    price = r1.price;
    return *this;
}
bool Room ::reserveRoom()
{

    int choice, choice2;
again:
    cout << "What Room Type do you prefer\n1-->Standard\n2-->Moderate\n3-->Superior\n4-->Junior Suite\n5-->Suite\n";
    cin >> choice;
    if (choice <= 0 || choice > 5)
    {
        cout << "Invalid choice" << endl;
        goto again;
    }
again2:
    cout << "What floor do you want to stay at? : ";
    cin >> choice2;
    choice2--;
    if (choice2 < 0 || choice2 > 4)
    {
        cout << "Invalid choice" << endl;
        goto again2;
    }
    switch (choice)
    {
    case 1:
        for (int j = 0; j < 10; j++)
        {
            if (allrooms[choice2][j].reservecheck == 0)
            {
                reservecheck = 1;
                allrooms[choice2][j].reservecheck = 1;
                cout << "Your Standard room has been booked on floor " << choice2 + 1 << "\nRoom number: " << j + 1 << endl
                     << endl;
                roomNum = j;
                break;
            }
        }
        break;
    case 2:
        for (int j = 10; j < 20; j++)
        {
            if (allrooms[choice2][j].reservecheck == 0)
            {
                reservecheck = 1;
                allrooms[choice2][j].reservecheck = 1;
                cout << "Your Moderate room has been booked on floor " << choice2 +1<< "\nRoom number: " << j + 1 << endl
                     << endl;
                roomNum = j;
                break;
            }
        }
        break;
    case 3:
        for (int j = 20; j < 30; j++)
        {
            if (allrooms[choice2][j].reservecheck == 0)
            {
                reservecheck = 1;
                allrooms[choice2][j].reservecheck = 1;
                cout << "Your Superior room has been booked on floor " << choice2+1 << "\nRoom number: " << j + 1 << endl
                     << endl;
                roomNum = j;
                break;
            }
        }
        break;
    case 4:
        for (int j = 30; j < 40; j++)
        {
            if (allrooms[choice2][j].reservecheck == 0)
            {
                reservecheck = 1;
                allrooms[choice2][j].reservecheck = 1;
                cout << "Your Junior Suite room has been booked on floor " << choice2+1 << "\nRoom number: " << j + 1 << endl
                     << endl;
                roomNum = j;
                break;
            }
        }
        break;
    case 5:
        for (int j = 40; j < 50; j++)
        {
            if (allrooms[choice2][j].reservecheck == 0)
            {
                reservecheck = 1;
                allrooms[choice2][j].reservecheck = 1;
                cout << "Your Suite room has been booked on floor " << choice2 +1<< "\nRoom number: " << j + 1 << endl
                     << endl;
                roomNum = j;
                break;
            }
        }
        break;
    default:
        cout << "All rooms of this category have been booked on this floor, try another floor" << endl;
        goto again;
        break;
    }
    cout << "How many days do you want to reserve your room for? : ";
    cin >> daysReserved;
    roomType = &allrooms[choice2][roomNum];
    floorNum = choice2;
    int min, hrs, d, m, y;
    cout << "Enter the time for when you want to reserve the room for; hours in 24hr format : ";
    cin >> hrs;
    while (hrs < 0 || hrs >=24)
    {
        if (hrs < 0)
        {
            cout << "invalid input, enter again : ";
            cin >> hrs;
        }
        else
        {
            hrs -= 24;
        }
    }
    cout << "Enter the time for when you want to reserve the room for; minutes in 24hr format : ";
    cin >> min;
    while (min > 59 || min < 0)
    {
        if (min < 0)
        {
            cout << "invalid input, enter again : ";
            cin >> min;
        }
        else
        {
            hrs++;
            min -= 59;
        }
    }
    checkin.setTime(hrs, min);
    cout << "Enter the day for when you want to reserve the room for: ";
    cin >> d;
    while (d < 0 || d > 31)
    {
        cout << "Invalid Input, enter again : ";
        cin >> d;
    }
    cout << "Enter the month number : ";
    cin >> m;
    while (m < 0 || m > 12)
    {
        cout << "Invalid Input, enter again : ";
        cin >> m;
    }
    cout << "Enter the year : ";
    cin >> y;
    checkin.setDate(y, m, d);
    d+=daysReserved;
    if (d > 31)
    {
        d = 1;
        m++;
    }
    if (m > 12)
    {
        m = 1;
        y++;
    }
    checkout.setDate(y, m, d);
    checkout.setTime(23, 59);
    return true;
}
Room ::~Room()
{
}
ostream &operator<<(ostream &output, Room r1)
{
    cout << " \t\tYOUR DETAILED REPORT " << endl
         << endl;
    char esc_char = 27;
    cout << esc_char << "[1m"
         << "Name : " << esc_char << "[0m" << r1.getcustomer()->getname() << endl;
    cout << esc_char << "[1m"
         << "Age : " << esc_char << "[0m" << r1.getcustomer()->getage() << endl;
    cout << esc_char << "[1m"
         << "Gender : " << esc_char << "[0m" << r1.getcustomer()->getgender() << endl;
    cout << esc_char << "[1m"
         << "ID Card Number : " << esc_char << "[0m" << r1.getcustomer()->getId() << endl;
    if (r1.getroomNum() < 10)
    {
        cout << esc_char << "[1m"
             << "Room Type : " << esc_char << "[0m"
             << " Standard" << endl;
    }
    else if (10 <= r1.getroomNum() < 20)
    {

        cout << esc_char << "[1m"
             << "Room Type : " << esc_char << "[0m"
             << " Moderate" << endl;
    }
    else if (20 <= r1.getroomNum() < 30)
    {
        cout << esc_char << "[1m"
             << "Room Type : " << esc_char << "[0m"
             << " Superior" << endl;
    }
    else if (30 <= r1.getroomNum() < 40)
    {
        cout << esc_char << "[1m"
             << "Room Type : " << esc_char << "[0m"
             << " Junior Suite" << endl;
    }
    else if (40 <= r1.getroomNum() < 50)
    {
        cout << esc_char << "[1m"
             << "Room Type : " << esc_char << "[0m"
             << " Suite" << endl;
    }
    cout << esc_char << "[1m"
         << "Check In Time : " << esc_char << "[0m" << r1.getcheckin().getTime() << endl;
    cout << esc_char << "[1m"
         << "Check In Date : " << esc_char << "[0m" << r1.getcheckin().getDate() << endl;
    cout << esc_char << "[1m"
         << "Check Out Time : " << esc_char << "[0m" << r1.getcheckout().getTime() << endl;
    cout << esc_char << "[1m"
         << "Check Out Date : " << esc_char << "[0m" << r1.getcheckout().getDate() << endl;
    cout << esc_char << "[1m"
         << "Days Reserved : " << esc_char << "[0m" << r1.getdaysReserved() << endl;
    cout << esc_char << "[1m"
         << "Floor Number : " << esc_char << "[0m" << r1.getfloorNum() + 1 << endl;
    cout << esc_char << "[1m"
         << "Room Number : " << esc_char << "[0m" << r1.getroomNum() + 1 << endl;
    return output;
}
ostream &operator<<(ostream &output, Customer c1)
{
    cout << " \t\tYOUR DETAILS " << endl
         << endl;
    char esc_char = 27;
    cout << esc_char << "[1m"
         << "Name : " << esc_char << "[0m" << c1.getname() << endl;
    cout << esc_char << "[1m"
         << "Age : " << esc_char << "[0m" << c1.getage() << endl;
    cout << esc_char << "[1m"
         << "Gender : " << esc_char << "[0m" << c1.getgender() << endl;
    cout << esc_char << "[1m"
         << "ID Card Number : " << esc_char << "[0m" << c1.getId() << endl;
    return output;
}
Standard :: Standard() 
{

}
Standard :: ~Standard() 
{

}
Moderate ::  Moderate() 
{

}
Moderate :: ~Moderate() 
{

}
Superior ::Superior() {}
Superior ::~Superior() {}
JuniorSuite ::JuniorSuite() {}
JuniorSuite ::~JuniorSuite() {}
Suite ::Suite() {}
Suite ::~Suite() {}